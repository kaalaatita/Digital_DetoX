import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Цифровой детокс",
    short_name: "Детокс",
    description: "Спокойное время без телефона.",
    start_url: "/",
    display: "standalone",
    background_color: "#f5f7f1",
    theme_color: "#f5f7f1",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" }],
  };
}
